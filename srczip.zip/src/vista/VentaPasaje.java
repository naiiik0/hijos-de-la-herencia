package vista;

import controlador.SistemaVentaPasajes;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;

public class VentaPasaje extends JFrame {
    private JPanel contentPane;
    private JTextField txtIDDocumento;
    private JTextField txtTipoDocumento;
    private JTextField txtFecha;
    private JTextField txtIDCliente;
    private JTextField textComunaSalida;
    private JTextField textComunaLlegada;
    private JSpinner spCantidad;
    private JButton btnIniciarVenta;
    private JComboBox cmbTipoDocumento;
    private JTable tblViajes;
    private JButton btnSelecionarViaje;
    private JTable tblAsientos;
    private JTextField txtIDPasajero;
    private JTextField txtAsiento;
    private JButton btnAgregarPasajero;
    private JComboBox cmbTipoPago;
    private JTextField txtNumeroTarjeta;
    private JButton btnPagarVenta;
    private JButton btnGenerarPasaje;
    private JButton btnCerrar;
    private JLabel lblMonto;
    private SistemaVentaPasajes sistema;

    public class ventapasaje extends JDialog {

        private SistemaVentaPasajes sistema;
        private DefaultTableModel modeloViajes;
        private DefaultTableModel modeloAsientos;

        public ventapasaje() {

            sistema = SistemaVentaPasajes.getInstance();

            setContentPane(contentPane);
            setModal(true);

            setTitle("Venta de Pasajes");
            setLocationRelativeTo(null);

            cargarTiposDocumento();
            cargarTiposPago();

            modeloViajes = new DefaultTableModel();
            modeloViajes.addColumn("Patente");
            modeloViajes.addColumn("Hora");
            modeloViajes.addColumn("Precio");
            modeloViajes.addColumn("Asientos");

            tblViajes.setModel(modeloViajes);

            modeloAsientos = new DefaultTableModel();
            modeloAsientos.addColumn("Asiento");
            modeloAsientos.addColumn("Estado");

            tblAsientos.setModel(modeloAsientos);

            btnCerrar.addActionListener(e -> dispose());

            btnIniciarVenta.addActionListener(e -> iniciarVenta());

            btnSelecionarViaje.addActionListener(e -> seleccionarViaje());

            btnAgregarPasajero.addActionListener(e -> agregarPasajero());

            btnPagarVenta.addActionListener(e -> pagarVenta());

            btnGenerarPasaje.addActionListener(e -> generarPasaje());
        }
        private void cargarTiposDocumento(){}
        private void cargarTiposPago(){}
        private void iniciarVenta(){}
        private void seleccionarViaje(){}
        private void agregarPasajero(){}
        private void pagarVenta(){}
        private void generarPasaje(){
        }
    }
    }
